Hello,

  I don't know anything about Ruby, but apparently this code works :-)
  
  I am confident that the code is fine, you may want to check it over
  but I have seen a demo site with charts displaying fine.
  
  You may have to experiment a little and read http://pullmonkey.com/projects/open_flash_chart/
  but you're a Ruby coder, you're already 43% smarter than me :-) You'll
  be able to figure it out :-)
  
  Have fun,
  
  monk.e.boy